package com.publicis.myBookingSitePublicis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
@EnableCircuitBreaker
@SpringBootApplication
public class MyBookingSitePublicisApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBookingSitePublicisApplication.class, args);
	}

}
