package com.publicis.mybookingsite.jpa.entity;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;


public class JPQLHelper {

	@PersistenceContext
	private EntityManager entityManager;

	public List<Object[]> findTheatresByCityMovieTime(String movieName, String cityName, Date startDate, Date endDate) {
		TypedQuery<Object[]> query = entityManager.createQuery(
				"SELECT c.name, th.name, st.startTime " + "FROM City c " + "JOIN c.cinemas th "
						+ "JOIN th.showtimes st " + "JOIN st.movie m " + "WHERE m.title = :movieName "
						+ "AND c.name = :cityName " + "AND st.startTime BETWEEN :startDate AND :endDate",
				Object[].class);
		query.setParameter("movieName", movieName);
		query.setParameter("cityName", cityName);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);

		List<Object[]> results = query.getResultList();

		return results;
	}

}
