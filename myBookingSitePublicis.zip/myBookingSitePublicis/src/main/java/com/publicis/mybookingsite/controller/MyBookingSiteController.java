package com.publicis.mybookingsite.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.publicis.mybookingsite.model.Booking;
import com.publicis.mybookingsite.model.Theatre;
import com.publicis.mybookingsite.orchestrator.BookingOrchestrator;

import com.publicis.mybookingsite.service.MyBookingSiteService;

@org.springframework.cloud.netflix.hystrix.EnableHystrix
@RestController
@RequestMapping("/api/v1")
public class MyBookingSiteController {

	private final MyBookingSiteService myBookingService;
	private final BookingOrchestrator myBookingOrchestrator;

	@Autowired
	public MyBookingSiteController(MyBookingSiteService myBookingService, BookingOrchestrator myBookingOrchestrator) {
		this.myBookingService = myBookingService;
		this.myBookingOrchestrator = myBookingOrchestrator;
	}

	/**
	 * Read: Browse theatres currently running the show (movie selected) in the
	 * town, including show timing by a chosen date
	 * 
	 * 
	 */
	@GetMapping("/Movies/{movieId}/listTheatre")
	public List<Theatre> ListTheatresInCityByDateTimeandMovie(@RequestParam String cityId, @RequestParam Date date,
			@PathVariable String movieId) {
		return myBookingService.findTheatresInCityByDateTimeAndMovie(cityId, movieId, date);

	}

	/**
	 * 
	 * Write: Book movie tickets by selecting a theatre, timing, and preferred seats
	 * for the day
	 * Assumes all the locking etc has already been done at the partner site or our booking site. 
	 * This is the final booking action
	 */

	@PostMapping("/Movies/{movieId}/bookTicket")
	public Booking BookTickets(@PathVariable String movieId, @RequestBody Booking bookingInputDetails) {

		return myBookingOrchestrator.orchestrateBooking(movieId,bookingInputDetails);

	}

}
