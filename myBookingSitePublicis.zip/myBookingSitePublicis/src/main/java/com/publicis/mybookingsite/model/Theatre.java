package com.publicis.mybookingsite.model;

import java.util.Date;
import java.util.List;

public class Theatre {
	private long theatreId;
	private long venueId;
	private Venue venue;

	private String TheatreName;
	private String theatreDesc;
	private String theatreEndPoint;
	private  String theatreType;
    

	private List<TheatreOffer> offers;

	// pruned list based on date, movie etc.
	private List<Show> shows;

	List<TheatreOffer> getTheatreOffers(Date start, Date end) {
		// query theatre offers table based on start and end date
		return null;
	}
	
	
	public String getTheatreType() {
		return theatreType;
	}

	public void setTheatreType(String theatreType) {
		this.theatreType = theatreType;
	}


	public Venue getVenue() {
		return venue;
	}

	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public long getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(long theatreId) {
		this.theatreId = theatreId;
	}

	public long getVenueId() {
		return venueId;
	}

	public void setVenueId(long venueId) {
		this.venueId = venueId;
	}

	public String getTheatreName() {
		return TheatreName;
	}

	public void setTheatreName(String theatreName) {
		TheatreName = theatreName;
	}

	public String getTheatreDesc() {
		return theatreDesc;
	}

	public void setTheatreDesc(String theatreDesc) {
		this.theatreDesc = theatreDesc;
	}

	public String getTheatreEndPoint() {
		return theatreEndPoint;
	}

	public void setTheatreEndPoint(String theatreEndPoint) {
		this.theatreEndPoint = theatreEndPoint;
	}
}
