package com.publicis.mybookingsite.model;

public class MovieCast {

	private long movieId;
	private long castId;
	private String castName;
	private String castDesc;
	private String castWikiLink;
	public long getMovieId() {
		return movieId;
	}
	public void setMovieId(long movieId) {
		this.movieId = movieId;
	}
	public long getCastId() {
		return castId;
	}
	public void setCastId(long castId) {
		this.castId = castId;
	}
	public String getCastName() {
		return castName;
	}
	public void setCastName(String castName) {
		this.castName = castName;
	}
	public String getCastDesc() {
		return castDesc;
	}
	public void setCastDesc(String castDesc) {
		this.castDesc = castDesc;
	}
	public String getCastWikiLink() {
		return castWikiLink;
	}
	public void setCastWikiLink(String castWikiLink) {
		this.castWikiLink = castWikiLink;
	}
}
