package com.publicis.mybookingsite.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Show {
	private  long theatreId;
	private  long showId;
   
   
   //String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
	private String showTime;
   
	private int maximumCapacity;
	private long movieId;
   
	private Date showDate;
	private List<Seat> seats;
   
public Date getShowDate() {
	return showDate;
}
public void setShowDate(Date showDate) {
	this.showDate = showDate;
}
public List<Seat> getSeats() {
	return seats;
}
public void setSeats(List<Seat> seats) {
	this.seats = seats;
}
public long getTheatreId() {
	return theatreId;
}
public void setTheatreId(long theatreId) {
	this.theatreId = theatreId;
}
public long getShowId() {
	return showId;
}
public void setShowId(long showId) {
	this.showId = showId;
}
public String getShowTime() {
	return showTime;
}
public void setShowTime(String showTime) {
	this.showTime = showTime;
}
public int getMaximumCapacity() {
	return maximumCapacity;
}
public void setMaximumCapacity(int maximumCapacity) {
	this.maximumCapacity = maximumCapacity;
}
public long getMovieId() {
	return movieId;
}
public void setMovieId(long movieId) {
	this.movieId = movieId;
}
}
