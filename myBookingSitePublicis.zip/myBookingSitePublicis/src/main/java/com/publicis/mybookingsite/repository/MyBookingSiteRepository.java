package com.publicis.mybookingsite.repository;

import java.util.Date;
import java.util.List;

import com.publicis.mybookingsite.model.Booking;
import com.publicis.mybookingsite.model.Seat;
import com.publicis.mybookingsite.model.Theatre;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

public class MyBookingSiteRepository {
	
	
	@PersistenceContext
	private EntityManager entityManager;

	public List<Object[]> findTheatresByCityMovieTime(String movieName, String cityName, Date startDate, Date endDate) {
		TypedQuery<Object[]> query = entityManager.createQuery(
				"SELECT c.name, th.name, st.startTime " + "FROM City c " + "JOIN c.cinemas th "
						+ "JOIN th.showtimes st " + "JOIN st.movie m " + "WHERE m.title = :movieName "
						+ "AND c.name = :cityName " + "AND st.startTime BETWEEN :startDate AND :endDate",
				Object[].class);
		query.setParameter("movieName", movieName);
		query.setParameter("cityName", cityName);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);

		List<Object[]> results = query.getResultList();

		return results;
	}
	
	
	//JPQL :)
	//writing sql code as we dont have access to dynamoDB
	String sql ="select theatre.theatreName, venue.address, show.showDate,show.showTime \n"
			+ "	 from show, theatre, movie, venue, city where \n"
			+ "	  venue.cityId = city.cityId \n"
			+ "	  and venue.venueid = theatre.venueid \n"
			+ "	  and theatre.theatreid = show.theatreid \n"
			+ "	  and city.cityId=cityId   //or city name \n"
			+ "	  and movie.movieId = movieId //or moviename \n"
			+ "	  and show.showdate = date;";

	public List<Theatre> findTheatresInCityByDateTimeAndMovie(String cityId, String movieId, Date date) {
		// TODO Auto-generated method stub
		//fetch from show, theatre, movie, venue, city data sources.
				/*
				 * select theatre.theatreName, venue.address, show.showDate,show.showTime
				 *  from show, theatre, movie, venue, city where 
				 *  venue.cityId = city.cityId 
				 *  and venue.venueid = theatre.venueid
				 *  and theatre.theatreid = show.theatreid
				 *  and city.cityId=cityId   //or city name
				 *  and movie.movieId = movieId //or moviename
				 *  and show.showdate = date;
				 */
		return null;
	}
	
	
	public String lockSeats(List<Seat> selSeats) {
		
		//lock the seats in the DB which have been selected for booking
		return null;
		
	}
	
	
	public Booking bookSeats(List<Seat> lockedSeats) {
		//persist in the Booking table and mark the seats status to booked.
		return null;
		
		
	}
	
	public Booking cancelAndReleaseBookedSeats(Booking booking) {
		//persist in the Booking table and mark the seats status to booked.
		return null;
		
		
	}
	
	



}
