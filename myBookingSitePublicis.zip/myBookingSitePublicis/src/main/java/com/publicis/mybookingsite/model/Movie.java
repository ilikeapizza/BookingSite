package com.publicis.mybookingsite.model;

import java.util.List;

public class Movie {
	
	private long movieId;
	private String movieName;
	private String movieTrailerS3Location;
	private String movieImagesS3Location;
	
	private List<MovieCast> moviecast;
	
	public List<MovieCast> getMoviecast() {
		return moviecast;
	}
	public void setMoviecast(List<MovieCast> moviecast) {
		this.moviecast = moviecast;
	}
	public long getMovieId() {
		return movieId;
	}
	public void setMovieId(long movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieTrailerS3Location() {
		return movieTrailerS3Location;
	}
	public void setMovieTrailerS3Location(String movieTrailerS3Location) {
		this.movieTrailerS3Location = movieTrailerS3Location;
	}
	public String getMovieImagesS3Location() {
		return movieImagesS3Location;
	}
	public void setMovieImagesS3Location(String movieImagesS3Location) {
		this.movieImagesS3Location = movieImagesS3Location;
	}
	

}
