package com.publicis.mybookingsite.model;

import java.util.List;

public class Booking {
	private long showId;
	private long userId = -1; // default -1 GUEST
	private long bookingId;
	private int bookingQuantity;
	private float totalPricePostDiscount;
	private String paymentGatewayInteractionId;
	private String partnerSiteInteractionId;
	private String qrCodeLocationInS3;
	private 	User bookedBy;

	private Theatre theatre;

	private List<BookingSeat> bookedSeats;

	private List<Seat> selectedSeats;

	private String bookingSiteHTTPResponseCode;

	public String getBookingSiteHTTPResponseCode() {
		return bookingSiteHTTPResponseCode;
	}

	public void setBookingSiteHTTPResponseCode(String bookingSiteHTTPResponseCode) {
		this.bookingSiteHTTPResponseCode = bookingSiteHTTPResponseCode;
	}

	public String getBookingSiteResponseExceptionMessage() {
		return bookingSiteResponseExceptionMessage;
	}

	public void setBookingSiteResponseExceptionMessage(String bookingSiteResponseExceptionMessage) {
		this.bookingSiteResponseExceptionMessage = bookingSiteResponseExceptionMessage;
	}

	String bookingSiteResponseExceptionMessage;

	public List<Seat> getSelectedSeats() {
		return selectedSeats;
	}

	public void setSelectedSeats(List<Seat> selectedSeats) {
		this.selectedSeats = selectedSeats;
	}

	public List<BookingSeat> getBookedSeats() {
		return bookedSeats;
	}

	public void setBookedSeats(List<BookingSeat> bookedSeats) {
		this.bookedSeats = bookedSeats;
	}

	public User getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(User bookedBy) {
		this.bookedBy = bookedBy;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	public long getShowId() {
		return showId;
	}

	public void setShowId(long showId) {
		this.showId = showId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	public int getBookingQuantity() {
		return bookingQuantity;
	}

	public void setBookingQuantity(int bookingQuantity) {
		this.bookingQuantity = bookingQuantity;
	}

	public float getTotalPricePostDiscount() {
		return totalPricePostDiscount;
	}

	public void setTotalPricePostDiscount(float totalPricePostDiscount) {
		this.totalPricePostDiscount = totalPricePostDiscount;
	}

	public String getPaymentGatewayInteractionId() {
		return paymentGatewayInteractionId;
	}

	public void setPaymentGatewayInteractionId(String paymentGatewayInteractionId) {
		this.paymentGatewayInteractionId = paymentGatewayInteractionId;
	}

	public String getPartnerSiteInteractionId() {
		return partnerSiteInteractionId;
	}

	public void setPartnerSiteInteractionId(String partnerSiteInteractionId) {
		this.partnerSiteInteractionId = partnerSiteInteractionId;
	}

	public String getQrCodeLocationInS3() {
		return qrCodeLocationInS3;
	}

	public void setQrCodeLocationInS3(String qrCodeLocationInS3) {
		this.qrCodeLocationInS3 = qrCodeLocationInS3;
	}
}
