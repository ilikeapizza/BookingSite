package com.publicis.mybookingsite.orchestrator;

//TODO ENUM
public class TheatreType {
public static final String externalType="EXTERNAL";
public static final String defaultType ="DEFAULT";
}
