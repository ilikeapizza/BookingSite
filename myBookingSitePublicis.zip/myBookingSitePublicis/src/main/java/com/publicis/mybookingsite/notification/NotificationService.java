package com.publicis.mybookingsite.notification;

import java.util.List;

import com.publicis.mybookingsite.model.Booking;

//TODO Micro service and uses aws sns or aws mq
//There can be more than one micro service for the specific interfaces depending on the scale, for now a single micro service
public class NotificationService {
	
	List<Notifier> notifiers;
	public Booking notify(Booking booking) throws Exception{
		
		for(Notifier notifier: notifiers) {
			// format the message and 
			
			notifier.format(booking);
			notifier.notify(booking);
		}
		
		//return status
		return null;
		
	}
	
	
public Booking cancelNotification(Booking booking){
		
		for(Notifier notifier: notifiers) {
			// format the message and 
			
				notifier.notify(booking);
		}
		
		//return status
		return null;
		
	}

}
