package com.publicis.mybookingsite.model;

public class TheatreOffer {
	
	private long theatreId;
	private long offerCode;
	
	public long getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(long theatreId) {
		this.theatreId = theatreId;
	}
	public long getOfferCode() {
		return offerCode;
	}
	public void setOfferCode(long offerCode) {
		this.offerCode = offerCode;
	}
	

}
