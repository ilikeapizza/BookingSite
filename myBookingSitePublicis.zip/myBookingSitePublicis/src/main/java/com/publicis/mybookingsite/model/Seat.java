package com.publicis.mybookingsite.model;

public class Seat {
	
	private long seatId;
	private long showId;
	private String seatType;
	private int rowNumber;
	private int seatNumber;


public long getSeatId() {
	return seatId;
}
public void setSeatId(long seatId) {
	this.seatId = seatId;
}
public long getShowId() {
	return showId;
}
public void setShowId(long showId) {
	this.showId = showId;
}
public String getSeatType() {
	return seatType;
}
public void setSeatType(String seatType) {
	this.seatType = seatType;
}
public int getRowNumber() {
	return rowNumber;
}
public void setRowNumber(int rowNumber) {
	this.rowNumber = rowNumber;
}
public int getSeatNumber() {
	return seatNumber;
}
public void setSeatNumber(int seatNumber) {
	this.seatNumber = seatNumber;
}

}
