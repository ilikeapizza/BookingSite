package com.publicis.mybookingsite.model;

public class MovieUserRating {
	private  long userId;
	private  float rating;
	private  long movieId;
  
  
public long getUserId() {
	return userId;
}
public void setUserId(long userId) {
	this.userId = userId;
}
public float getRating() {
	return rating;
}
public void setRating(float rating) {
	this.rating = rating;
}
public long getMovieId() {
	return movieId;
}
public void setMovieId(long movieId) {
	this.movieId = movieId;
}
  
}
