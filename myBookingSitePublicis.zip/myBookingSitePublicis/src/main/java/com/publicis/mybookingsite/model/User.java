package com.publicis.mybookingsite.model;

import java.util.Date;
import java.util.List;

public class User {
	private long userId;
	private String userName;
	private int age;
	private  String gender;
	private  String emailId;
	private  int userContactNumber;
	private  String otherDetails;
  
	private List<MovieUserRating> ratings;
	private List<UserOffer> offers;

  List<UserOffer> getUserOffers(Date start, Date end){
	  
	  //query useroffertable based on start and end
	  return null;
  }
  
 public List<MovieUserRating> getRatings() {
	return ratings;
}
public void setRatings(List<MovieUserRating> ratings) {
	this.ratings = ratings;
}
public List<UserOffer> getOffers() {
	return offers;
}
public void setOffers(List<UserOffer> offers) {
	this.offers = offers;
}
public long getUserId() {
	return userId;
}
public void setUserId(long userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public int getUserContactNumber() {
	return userContactNumber;
}
public void setUserContactNumber(int userContactNumber) {
	this.userContactNumber = userContactNumber;
}
public String getOtherDetails() {
	return otherDetails;
}
public void setOtherDetails(String otherDetails) {
	this.otherDetails = otherDetails;
}
}
