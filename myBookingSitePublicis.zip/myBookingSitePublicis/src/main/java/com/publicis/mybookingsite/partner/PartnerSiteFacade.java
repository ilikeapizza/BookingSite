package com.publicis.mybookingsite.partner;

import java.util.Date;
import java.util.List;

import com.publicis.mybookingsite.model.Seat;

//TODO each partner can have their own site, so we need to make the REST API invocation dynamic based on the endpoint and also based on the keys to be used for invoking the endpoint which will be different per end point
public class PartnerSiteFacade {

	
	public List<Seat> getAvailableSeatsForSelection(String movie, String show, Date time) {
		//TODO or rather stub as this needs to be an actual REST API from partner site'
		return null;
		
	}

	
	public String lockSeatsForSelection(List<Seat> lockSeats) {
		
		//TODO use partner api to lock the seats for booking
		return null;
	}
	
	
	public PartnerBookingDetails bookselectedSeats(List<Seat> selSeatsForBooking) throws Exception{
		//TODO use partner api to book the seats for booking. return the transaction id, status
		return null;
	}
	
	public PartnerBookingDetails cancelBookingOnTransactionFailure(PartnerBookingDetails pbd) {
		
		// TODO call partner api to cancel the booking if any of the payment gateway or notification etc fails in the SAGA 
		return null;
	}
}




