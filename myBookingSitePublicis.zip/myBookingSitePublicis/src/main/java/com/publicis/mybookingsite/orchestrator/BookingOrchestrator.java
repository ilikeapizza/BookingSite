package com.publicis.mybookingsite.orchestrator;

import java.time.chrono.AbstractChronology;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.stereotype.Service;

import com.publicis.mybookingsite.model.Booking;
import com.publicis.mybookingsite.notification.NotificationService;
import com.publicis.mybookingsite.partner.PartnerBookingDetails;
import com.publicis.mybookingsite.partner.PartnerSiteFacade;
import com.publicis.mybookingsite.payment.PaymentGatewayService;
import com.publicis.mybookingsite.repository.MyBookingSiteRepository;
import com.publicis.mybookingsite.service.MyBookingSiteService;

//TODO micro service on its own
@Service
public class BookingOrchestrator {
	@Autowired
	PartnerSiteFacade partSiteFacade;
	@Autowired
	PaymentGatewayService payGatewayserv;
	@Autowired
	NotificationService notifServ;
	@Autowired
	MyBookingSiteService mybookSiteReposService;

	@Autowired
	LookUpMicroServiceInstance lookupServiceinstanceHelper;

	public Booking orchestrateBooking(String movieId, Booking bookingInputDetails) {
		// TODO Auto-generated method stub

		// SAGA synchronous
		// would prefer to send a message and then let the other micro services consume,
		// but for the sake of POC using synchronous
		// messages are better so that on the revert side we need not rely on the
		// partner site to be up and retry... retries become far easier, but now one has
		// to poll or consume a message back
		boolean overallTransactionFailed = true;
		PartnerBookingDetails pbd = null;
		;
		// TODO could use a different POJO for the post booking transaction side of
		// things for Booking pojo
		Booking paymentGwayTransactionDetails = null;
		Booking mybookingSiteTransactionDetails = null;
		Booking notifierTransactionDetails = null;

		try {
			if (bookingInputDetails.getTheatre().getTheatreType().equals(TheatreType.externalType)) {
				// if booking type is external, call the bookSeatsAPI, if the previous seats are
				// no longer available for whatever reason, it will throw error. These seats
				// remind you were already locked using the partners lockSeats API.

				pbd = partSiteFacade.bookselectedSeats(bookingInputDetails.getSelectedSeats());

				paymentGwayTransactionDetails = payGatewayserv.executeTransaction(bookingInputDetails);

				// lookupNotifServices via LookupMicroServiceInstance in a load balanced fashion
				notifierTransactionDetails = lookupNotificationService().notify(bookingInputDetails);
				// lookupmicroServiceInstance using LookupMicroServiceInstance in a load
				// balanced fashion
				mybookingSiteTransactionDetails = lookupmyBookingSiteService()
						.bookSeats(bookingInputDetails.getSelectedSeats());
				overallTransactionFailed = false;
			} else {

				// if booking via the site for a theatre that does not have any site of their
				// own, no need to call any partnerside api as it does not exist
				paymentGwayTransactionDetails = payGatewayserv.executeTransaction(bookingInputDetails);

				// lookupNotifServices via LookupMicroServiceInstance in a load balanced fashion
				notifierTransactionDetails = lookupNotificationService().notify(bookingInputDetails);
				// lookupmicroServiceInstance using LookupMicroServiceInstance in a load
				// balanced fashion
				mybookingSiteTransactionDetails = lookupmyBookingSiteService()
						.bookSeats(bookingInputDetails.getSelectedSeats());
				overallTransactionFailed = false;
			}

		} catch (Exception e) {
			// TODO SEND REVERT ACTION MESSAGES from the orchestrator using booking details
			// which now has the transactionIds

			if (overallTransactionFailed) {
				// call revert action calls to the other micro services involved in the
				// transaction
				if (bookingInputDetails.getTheatre().getTheatreType().equals(TheatreType.externalType))
					partSiteFacade.cancelBookingOnTransactionFailure(pbd);

				payGatewayserv.revertTransaction(paymentGwayTransactionDetails);

				// lookupmicroServiceInstance using LookupMicroServiceInstance in a load
				// balanced fashion
				lookupmyBookingSiteService().cancelAndReleaseBookedSeats(mybookingSiteTransactionDetails);

				//// lookupmicroServiceInstance using LookupMicroServiceInstance in a load
				//// balanced fashion

				lookupNotificationService().cancelNotification(notifierTransactionDetails);

			}
		}
		return mybookingSiteTransactionDetails;
	}

	private MyBookingSiteRepository lookupmyBookingSiteService() {
		ServiceInstance si = lookupServiceinstanceHelper.lookupMicroserviceInstances("mybookingSite-repos-service");
		return null;

	}

	private NotificationService lookupNotificationService() {
		// TODO Auto-generated method stub
		ServiceInstance si = lookupServiceinstanceHelper.lookupMicroserviceInstances("notification-service");
		return null;

	}

}
