package com.publicis.mybookingsite.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import com.publicis.mybookingsite.model.Booking;
import com.publicis.mybookingsite.model.Seat;
import com.publicis.mybookingsite.model.Theatre;
import com.publicis.mybookingsite.repository.MyBookingSiteRepository;


@Service
public class MyBookingSiteService {

	@Autowired
	private MyBookingSiteRepository repository;

	@HystrixCommand(fallbackMethod = "fallbackfindTheatresMethod")
	public List<Theatre> findTheatresInCityByDateTimeAndMovie(String cityId, String movieId, Date date) {

		return repository.findTheatresInCityByDateTimeAndMovie(cityId, movieId, date);
	}

	public List<Theatre> fallbackfindTheatresMethod() {
		return null;
	}

	@HystrixCommand(fallbackMethod = "fallbackbookSeatsMethod")
	public Booking bookSeats(List<Seat> selectedSeats) {
		// TODO Auto-generated method stub
		return repository.bookSeats(selectedSeats);
	}

	public Booking fallbackbookSeatsMethod() {
		return null;
	}

	public void cancelAndReleaseBookedSeats(Booking mybookingSiteTransactionDetails) {
		// TODO Auto-generated method stub
		repository.cancelAndReleaseBookedSeats(mybookingSiteTransactionDetails);
	}

}
