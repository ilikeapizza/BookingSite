package com.publicis.mybookingsite.partner;

public class PartnerBookingDetails {

	String operationStatus;
	String bookingId;
	String partnerTransactionId;
	public String getOperationStatus() {
		return operationStatus;
	}
	public void setOperationStatus(String operationStatus) {
		this.operationStatus = operationStatus;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getPartnerTransactionId() {
		return partnerTransactionId;
	}
	public void setPartnerTransactionId(String partnerTransactionId) {
		this.partnerTransactionId = partnerTransactionId;
	}
}
