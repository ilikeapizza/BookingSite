package com.publicis.mybookingsite.notification;

import com.publicis.mybookingsite.model.Booking;

public class EmailNotifier implements Notifier {

	@Override
	public String notify(Booking booking) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String format(Booking booking) {
		return null;
		// TODO Auto-generated method stub
		
	}

}
