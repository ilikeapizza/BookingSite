package com.publicis.mybookingsite.model;

public class SeatPrice {
//TODO better inheritance
}
