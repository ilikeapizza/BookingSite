package com.publicis.mybookingsite.model;

public class DefaultSeatPrice extends SeatPrice{
	private String seatType;
	private float seatPrice;
	public String getSeatType() {
		return seatType;
	}
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}
	public float getSeatPrice() {
		return seatPrice;
	}
	public void setSeatPrice(float seatPrice) {
		this.seatPrice = seatPrice;
	}

}
