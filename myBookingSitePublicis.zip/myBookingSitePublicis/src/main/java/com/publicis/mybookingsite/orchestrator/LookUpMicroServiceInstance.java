package com.publicis.mybookingsite.orchestrator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Random;

@Service
public class LookUpMicroServiceInstance {
	@Autowired
	private DiscoveryClient discoveryClient;

	public ServiceInstance lookupMicroserviceInstances(String serviceName) {
		List<ServiceInstance> instances = discoveryClient.getInstances(serviceName);
		 Random rand = new Random();
          int randomInstance = rand.nextInt(instances.size());
		//TODO currently returning a random instance .
		return instances.get(randomInstance);
	}
}