package com.publicis.mybookingsite.model;

import java.util.Date;

public class Offer {
	private  long offerCode;
	private  String merchantName;
	private  Date offerStartTime;
	private   Date offerEndTime;
	private    float offerPercentage;
	private    float offerDiscountPriceTotal;
   
   
public long getOfferCode() {
	return offerCode;
}
public void setOfferCode(long offerCode) {
	this.offerCode = offerCode;
}
public String getMerchantName() {
	return merchantName;
}
public void setMerchantName(String merchantName) {
	this.merchantName = merchantName;
}
public Date getOfferStartTime() {
	return offerStartTime;
}
public void setOfferStartTime(Date offerStartTime) {
	this.offerStartTime = offerStartTime;
}
public Date getOfferEndTime() {
	return offerEndTime;
}
public void setOfferEndTime(Date offerEndTime) {
	this.offerEndTime = offerEndTime;
}
public float getOfferPercentage() {
	return offerPercentage;
}
public void setOfferPercentage(float offerPercentage) {
	this.offerPercentage = offerPercentage;
}
public float getOfferDiscountPriceTotal() {
	return offerDiscountPriceTotal;
}
public void setOfferDiscountPriceTotal(float offerDiscountPriceTotal) {
	this.offerDiscountPriceTotal = offerDiscountPriceTotal;
}
}
