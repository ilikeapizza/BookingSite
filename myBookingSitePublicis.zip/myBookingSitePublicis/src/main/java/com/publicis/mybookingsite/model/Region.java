package com.publicis.mybookingsite.model;

import java.util.List;

public class Region {
	private List<City> cities;

public List<City> getCities() {
	return cities;
}

public void setCities(List<City> cities) {
	this.cities = cities;
}
  
}
