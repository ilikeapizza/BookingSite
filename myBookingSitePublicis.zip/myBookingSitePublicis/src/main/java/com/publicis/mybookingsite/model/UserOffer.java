package com.publicis.mybookingsite.model;

public class UserOffer {
	
	private long userId;
	private long offerCode;


public long getUserId() {
	return userId;
}
public void setUserId(long userId) {
	this.userId = userId;
}
public long getOfferCode() {
	return offerCode;
}
public void setOfferCode(long offerCode) {
	this.offerCode = offerCode;
}
}
