package com.publicis.mybookingsite.notification;

import com.publicis.mybookingsite.model.Booking;

public  interface  Notifier {
	
	public String notify(Booking booking);

	public String format(Booking booking);
}
