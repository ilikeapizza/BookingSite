package com.publicis.mybookingsite.payment;

import com.publicis.mybookingsite.model.Booking;

public class PaymentGatewayService {

	// response could be a better POJO
	public Booking executeTransaction(Booking booking) {
		//use OAuth etc for payment gateway interaction
		return null;
	}
	
	// response could be a better POJO
		public Booking revertTransaction(Booking booking) {
			//use OAuth etc for payment gateway interaction
			return null;
		}
	
}
