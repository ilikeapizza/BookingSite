package com.publicis.myBookingSitePublicis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBookingSitePublicisApplicationTests {

	@Test
	void contextLoads() {
	}

}
